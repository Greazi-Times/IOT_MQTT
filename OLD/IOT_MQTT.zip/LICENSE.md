Copyright (c) 2021 - 2022. Greazi - All rights reserved
Unauthorized copying of this file, via any medium is strictly prohibited
Proprietary and confidential

This project has been made specially for school and can only be used for educational use only.
Using this project or parts of this project without authorisation is not permitted

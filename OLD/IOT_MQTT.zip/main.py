import constants
import system.logger as logger
import system.publisher as mqtt
import datetime
import network
import utime
from machine import ADC, Pin

# Date time component
e = datetime.datetime.now()

# Valve components
p2 = Pin(2, Pin.IN, Pin.PULL_UP)

# Moisture components
soil = ADC(Pin(26))
min_moisture = 0
max_moisture = 65535

# The connection to the network
station = network.WLAN(network.STA_IF)
station.active(True)


# Returns the date of today
def get_date():
    return "%s/%s/%s %s:%s:%s" % (e.day, e.month, e.year, e.hour, e.minute, e.second)


# Returns the values of the HW-390 Moisture Sensor
def get_moisture():
    return (max_moisture - soil.read_u16()) * 100 / (max_moisture - min_moisture)


# Returns the value of the valve
def get_valve():
    return p2


# The main system that runs in a loop
counter = 1
while True:
    # Connect to the network
    if not station.isconnected():
        print(counter, "connecting...")
        counter = counter + 1
        station.connect(constants.network.host, constants.network.password)
        utime.sleep(5)

    # Check if system is connected to the network
    if (station.isconnected()):
        while True:
            # Send success message
            print("Connected !")
            print(station.ifconfig())

            # Try to connect to the MQTT system.
            try:

                # Send all data to MQTT server
                mqtt.push('DZHF/NOWEY/DATE', get_date())
                mqtt.push('DZHF/NOWEY/MOISTURE', get_moisture())
                mqtt.push('DZHF/NOWEY/VALVE', get_valve())

                # Add the data object to the log file
                logger.add(get_date(), get_moisture(), get_valve())

                # TODO: Check if this is correct and what the outputs are from soil
                print("Soil value: " + soil)
                if(soil <= 10):
                    p2(1)
                if(soil >= 11):
                    p2(0)

                # Wait a little before continuing
                utime.sleep(5)

            # Send an exception
            except OSError as e:
                print(e)

            # Wait a little before continuing
            utime.sleep(5)

    # Not connected but still run the system
    else:
        # Add the data object to the log file
        logger.add(get_date(), get_moisture(), get_valve())

# An disabled print for checking the moisture system
# print("moisture: " + "%.2f" % get_moisture() + "% (adc: " + str(soil.read_u16()) + ")")
